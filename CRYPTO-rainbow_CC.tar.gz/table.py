import hashlib, chain, cPickle, random, string, time, reductor, csv

# chris -> 711c73f64afdce07b7e38039a96d2224209e9a6c

# num_Chain = 2**(2.0/3)
# chain_len = 2**(1.0/3)
def genTable(num_chars=5, num_chains=50000, chain_len=250, debug=False):
	# We keep two dictionaries: {plain,hash}, {hash,plain}
	# This allows for faster lookups, good memory sacrifice to save time
	forward_dic = {} # {plain,hash}
	backward_dic = {} # {hash,plain}

	for x in range(num_chains):
		if (x % 100 == 0):
			print 'have generated ', x

		rnd_string = ''.join(random.choice(string.lowercase) for i in range(num_chars))

		while rnd_string in forward_dic.keys():
			rnd_string = ''.join(random.choice(string.lowercase) for i in range(num_chars))

		(key, val) = chain.chain_plain(rnd_string, forward_dic.keys(), chain_len, debug)

		while key == None:
			print 'found a Collision'
			rnd_string = ''.join(random.choice(string.lowercase) for i in range(num_chars))

			while rnd_string in forward_dic.keys():
				rnd_string = ''.join(random.choice(string.lowercase) for i in range(num_chars))
			(key, val) = chain.chain_plain(rnd_string, forward_dic.keys(), chain_len, debug)

		forward_dic[key] = val
		backward_dic[val] = key

	w = csv.writer(open("forward_dic.csv", "w"))
	for key, val in forward_dic.items():
	    w.writerow([key, val])
	
	z = csv.writer(open("backward_dic.csv", "w"))
	for key, val in backward_dic.items():
   		z.writerow([key, val])
	return (forward_dic, backward_dic)


def crackSHA1(hashval, forward_dic, backward_dic, debug=True):


	indx = len(forward_dic.values())
	while hashval not in forward_dic.values() and indx >= 0:
		indx -= 1
		hashval = reductor.reduce_hash(hashval,5, indx, False)

		if debug:
			print 'curr indx: ', indx

	if hashval in forward_dic.values():
		return chain.find_hash_in_chain(backward_dic[hashval], hashval)
	else:
		return 'no luck finding it after checking ', indx


# cPickle.dump(annexed,pickleFile)
# annexed = cPickle.load(pickleFile)

start = time.time()
(forward_dic, backward_dic) = genTable()
print crackSHA1('ad691d435b47042374277cd89e2c156683e2ba70', forward_dic, backward_dic)
print crackSHA1('26acff75e3779e8627bca217e3f5e5c60405d631', forward_dic, backward_dic)
print crackSHA1('79ce1c8238d48f94200c8bfc543d4e78a23c3cd8', forward_dic, backward_dic)
print crackSHA1('cb529d394166e3374b9a2b50ea4bae6d3daa5591', forward_dic, backward_dic)
print crackSHA1('bd909fdab812aa2e0ccbfe23fc84da5cae68cad6', forward_dic, backward_dic)
print crackSHA1('7bc70bc7a58c340e993fef5a82070c029a174f14', forward_dic, backward_dic)
print crackSHA1('1ce2d6f9491304c88e8154c3a2271ca04694f256', forward_dic, backward_dic)
print crackSHA1('8b83cb03a8042a8d87009a45fbac32fc746f29c0', forward_dic, backward_dic)
print crackSHA1('e687ad1057c96571974d3750a253917d3d823f05', forward_dic, backward_dic)
print crackSHA1('63e02fb4eabc3959540c4ab40becf245dd6f295f', forward_dic, backward_dic)
print crackSHA1('d92d266f60eff2f6bd9f5ffa522c8dd7830ac6d2', forward_dic, backward_dic)
print crackSHA1('c1448a59c6f3719863b1e3e2cdb7baee30b993c0', forward_dic, backward_dic)
print crackSHA1('b9279dd530966836a04c9881b1bdb4a1aae3c572', forward_dic, backward_dic)
print crackSHA1('0d8be45f65c033345972cb416161d59ef2d71451', forward_dic, backward_dic)
print crackSHA1('6cd93a1728a02d69582e4882d0e61c5103dba107', forward_dic, backward_dic)





# print crackSHA1(conversions.b64_to_hex('7iEjysAibZbmoZP/9v5w3MPnUW0='))
# print crackSHA1(conversions.b64_to_hex('qwaEUA9V60H/7EDP4cKZY/x36NI='))
end = time.time()
print end - start
